"""CLI interface for running the Strands Incident Agent."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

from .agent import check_model_provider_status, create_incident_agent
from .tools import FIXTURES_DIR, analyze_incident_logs


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Incident Time Machine: Strands Agent CLI"
    )
    parser.add_argument(
        "fixture",
        type=str,
        help="Name or relative path of the fixture file inside the authorized fixtures directory (e.g. 'incident_out_of_order.json').",
    )
    parser.add_argument(
        "--tool-only",
        action="store_true",
        help="Execute only the deterministic Strands tool directly without running the agent loop.",
    )

    args = parser.parse_args(argv)
    fixture_input = args.fixture.strip()

    print("=" * 70)
    print("      INCIDENT TIME MACHINE - STRANDS AGENT HARNESS")
    print("=" * 70)
    print(f"Target Fixture       : {fixture_input}")
    print(f"Authorized Directory : {FIXTURES_DIR}")

    # Check model provider availability
    is_available, status_msg, _ = check_model_provider_status()
    print(f"Model Provider Status: {status_msg}")

    if args.tool_only:
        print("\n--- Executing Strands Custom Tool: analyze_incident_logs ---")
        tool_result = analyze_incident_logs(fixture_input)
        if tool_result.get("status") == "error":
            print(f"Tool Error [{tool_result.get('error_code')}]: {tool_result.get('message')}", file=sys.stderr)
            return 1

        print(f"Timeline Events Processed : {len(tool_result.get('timeline', []))}")
        print(f"Correlated Traces         : {len(tool_result.get('traces', {}))}")
        print(f"Earliest Recorded Error   : {tool_result.get('earliest_recorded_error')}")
        print(f"Hypotheses Generated      : {len(tool_result.get('hypotheses', []))}")
        print(f"Unknowns / Telemetry Gaps : {len(tool_result.get('unknowns', []))}")
        print("=" * 70)
        return 0

    print("\n--- Initializing Strands Agent ---")
    agent, provider_info = create_incident_agent(target_fixture=fixture_input)
    print(f"Agent Harness Active : {provider_info}")
    print("\n--- Invoking Agent with Incident Investigation Prompt ---")

    prompt = (
        f"Investigate the incident described in fixture '{fixture_input}'. "
        "Invoke the 'analyze_incident_logs' tool to inspect the deterministic timeline. "
        "Do not invent event IDs or telemetry. Adhere strictly to all system prompt safeguards."
    )

    try:
        response = agent(prompt)
        print("\n--- Agent Response ---")
        print(response)
        print("=" * 70)
        return 0
    except Exception as exc:
        print(f"Agent Execution Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
