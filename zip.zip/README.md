# Incident Time Machine (Local Python MVP)

> A deterministic log-reconstruction and incident-analysis engine designed for agentic root-cause investigation in distributed systems.

Built for the AWS Agent-Tool Hackathon as the foundation for autonomous incident triage tools.

---

## 1. Architectural Invariants

Incident Time Machine adheres to five non-negotiable principles:

1. **Pure Determinism**: Ingesting the same logs always produces the exact same timeline, event IDs, traces, and analytical conclusions across operating systems and Python versions. Tie-breaking for identical timestamps uses the initial ingestion sequence.
2. **Untrusted Data Guardrail**: All log contents, payloads, and error strings are treated as **untrusted data**. Prompt injection strings (e.g. `"Ignore previous instructions..."`) embedded in log bodies are never interpreted as instructions.
3. **No Temporal Fallacy (*Post Hoc Ergo Propter Hoc*)**: **Chronological sequence does NOT prove causation.** The earliest recorded error is explicitly identified as an observable symptom, never assumed to be the root cause.
4. **Evidence-Backed Hypotheses**: Every hypothesis must explicitly cite concrete event IDs (`evt-0001`, `evt-0002`). Uncited claims are rejected.
5. **Explicit Uncertainty & Telemetry Gaps**: Hypotheses explicitly document uncertainties, alternative explanations (e.g., network partitions, resource saturation), falsification criteria, and missing telemetry.

---

## 2. Directory Structure

```text
Incident-AWS/
├── .agents/
│   └── skills/
│       ├── incident-engineering/SKILL.md      # Deterministic engine standards
│       ├── incident-investigation/SKILL.md    # Investigation & untrusted data guidelines
│       └── python-testing/SKILL.md            # pytest coverage & reporting protocols
├── lambda_function.py                        # AWS Lambda entrypoint (`lambda_function.lambda_handler`)
├── fixtures/
│   ├── incident_out_of_order.json            # Synthetic cascade outage (scrambled order)
│   └── healthy_traffic.json                  # Multi-service baseline traffic (no errors)
├── src/
│   └── incident_time_machine/
│       ├── __init__.py                       # Package exports
│       ├── agent.py                          # Strands Agent factory & provider inspection
│       ├── agent_cli.py                      # Strands Agent interactive CLI runner
│       ├── cli.py                            # Standalone engine CLI parser & runner
│       ├── engine.py                         # Deterministic reconstruction & correlation
│       ├── lambda_handler.py                 # Pure AWS Lambda request parser & executor
│       ├── models.py                         # Dataclasses (Event, Trace, Hypothesis, Report)
│       ├── parser.py                         # ISO 8601 & schema validator
│       ├── prompts.py                        # Agent system prompt & anti-hallucination safeguards
│       ├── tools.py                          # Strands `@tool analyze_incident_logs` with sandbox jail
│       └── __main__.py                       # Module entrypoint (`python -m src.incident_time_machine`)
├── tests/
│   ├── __init__.py
│   ├── test_agent.py                         # Strands tool & agent integration test suite (11 tests)
│   ├── test_engine.py                        # Core deterministic engine test suite (12 tests)
│   └── test_lambda_handler.py                # AWS Lambda handler test suite (13 tests)
├── DEPLOYMENT.md                             # Comprehensive AWS Lambda deployment guide
├── requirements.txt                          # Dependencies documentation
└── README.md                                 # Project documentation
```

---

## 3. Dependencies

### Core Engine & Lambda Runtime: Zero External Dependencies
Both the deterministic engine and the AWS Lambda handler are built 100% on the Python 3.11+ standard library:
- `dataclasses`: Type-safe immutable data structures.
- `datetime`: Strict ISO 8601 timezone-aware parsing and UTC conversion.
- `json`: Fixture ingestion and serialization.
- `enum`: Log level categorization.
- `typing`: Strict type annotations.
- `base64`: Decoding API Gateway proxy payloads.

> **Zero Lambda Packaging Overhead**: The Lambda package requires NO external pip packages. Size is < 50 KB.

### Agent Framework & Tool Integration:
- `strands-agents>=1.62.0`: The official Strands Agents Python SDK providing the `@tool` decorator, `Agent` harness, and provider bindings.

### Model Providers (Optional / Environment-Driven):
- **Google Gemini**: Requires `google-genai` and `GEMINI_API_KEY` (or `GOOGLE_API_KEY`).
- **Amazon Bedrock**: Included via `boto3` in `strands-agents` (requires AWS credentials).
- **Hermetic Mock**: Built-in deterministic mock model (`DeterministicMockIncidentModel`) for zero-credential testing and offline CI/CD.

### Development & Test:
- `pytest>=8.0.0`: Required to execute the test suite and verify test invariants.

---

## 4. Usage & Execution Commands

### A. AWS Lambda Handler (Local Invocation & Testing)
Run the complete Lambda test suite:
```bash
python -m pytest tests/test_lambda_handler.py -v
```

### B. Strands Agent CLI (Agent Harness Invoking Custom Tool)
```bash
# Investigate out-of-order incident with Strands Agent
python -m src.incident_time_machine.agent_cli incident_out_of_order.json

# Investigate healthy traffic fixture
python -m src.incident_time_machine.agent_cli healthy_traffic.json

# Direct Strands Tool Execution without LLM Loop
python -m src.incident_time_machine.agent_cli incident_out_of_order.json --tool-only
```

### C. Core Deterministic Engine CLI
```bash
python -m src.incident_time_machine fixtures/incident_out_of_order.json
python -m src.incident_time_machine fixtures/healthy_traffic.json
python -m src.incident_time_machine fixtures/incident_out_of_order.json --json
```

---

## 5. Test Suite Verification (36 Tests Passed)

Run the complete test suite with pytest:
```bash
python -m pytest -v --tb=short
```

### Verified Test Results (36/36 Passed)
- `tests/test_agent.py`: 11 tests verifying Strands tool invocation, output schema, path traversal defenses (`ACCESS_DENIED`), invalid arguments, and mock agent loop.
- `tests/test_engine.py`: 12 tests verifying deterministic chronological sorting, secondary tie-breakers for duplicate timestamps, cross-service correlation, malformed/timezone-naive timestamp quarantining, and hypothesis evidence integrity.
- `tests/test_lambda_handler.py`: 13 tests verifying direct list invocation, `{"logs": [...]}`, API Gateway envelopes, base64 payloads, Bedrock Agent Action Group payloads, 400 Bad Request validations, and zero-framework independence.

---

## 6. AWS Lambda Deployment

See [DEPLOYMENT.md](DEPLOYMENT.md) for full deployment instructions:
- **Runtime**: `Python 3.12` or `Python 3.11`
- **Handler**: `lambda_function.lambda_handler`
- **Memory**: `256 MB`
- **Timeout**: `30 seconds`
- **Architecture**: `arm64` (Graviton) or `x86_64`
4. `test_missing_and_empty_request_ids`: Events lacking request IDs are safely retained in an unassociated pool.
5. `test_malformed_timestamps`: Non-ISO and corrupted timestamps are quarantined into `validation_errors` without engine crash.
6. `test_timezone_naive_timestamp_rejection`: Timestamps lacking timezone offsets (`Z` or `±HH:MM`) are strictly rejected.
7. `test_missing_required_fields`: Records missing `service`, `level`, or `message` are cleanly quarantined.
8. `test_healthy_traffic_fixture`: Normal logs yield zero errors and high-confidence baseline health hypothesis.
9. `test_incident_out_of_order_fixture`: Reconstructs cascading failure, identifies earliest error, asserts evidence citations, and verifies explicit causation disclaimers.
10. `test_untrusted_log_content_payload_safety`: Prompt injection text embedded in log messages is treated as inert string data.

---

## 6. Next Steps (Hackathon Roadmap)

- [ ] **Agent Tool Interface**: Wrap the engine as a callable tool for LLM agents (Claude / Bedrock / Gemini).
- [ ] **AWS CloudWatch Ingestion**: Stream real CloudWatch Logs via boto3 into the engine.
- [ ] **Strands Integration**: Orchestrate multi-step incident triage workflows.
